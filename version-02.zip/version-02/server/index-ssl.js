// CONFIG

const port = 8080;
const certFile = '/path/to/cert.pem';
const keyFile = '/path/to/key.pem';

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

const fs = require('fs');
const https = require('https');
const WebSocket = require('ws');

const server = https.createServer({
  cert: fs.readFileSync(certFile),
  key: fs.readFileSync(keyFile),
});

const wss = new WebSocket.Server({server});

console.log(`starting websocket server on port ${port}`);

wss.on('connection', ws => {
  ws.on('message', message => {
    console.log('received: %s', message);
    
    wss.clients.forEach(client => {
      if(client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  });
});

server.listen(port);
