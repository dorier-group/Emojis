// CONFIG

const port = 8080;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

const WebSocket = require('ws');

const wss = new WebSocket.Server({
  port,
});

console.log(`starting websocket server on port ${port}`);

wss.on('connection', ws => {
  ws.on('message', message => {
    console.log('received: %s', message);
    
    wss.clients.forEach(client => {
      if(client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  });
});
